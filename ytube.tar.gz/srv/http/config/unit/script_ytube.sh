#!/bin/bash

# if [ ! -f /opt/ext1 ]; then
# touch /opt/ext1
#echo "Đã thực hiện touch"
#echo "Đã thực hiện lệnh xóa"
#systemctl daemon-reload
#systemctl restart localbrowser.service
#systemctl stop localbrowser.service
# fi
systemctl stop localbrowser.service
#find /root/.mozilla/firefox -maxdepth 1 -type d -name '*.default-release' -exec rm -rf {} \;
#find /root/.mozilla/firefox -maxdepth 1 -type d -name '*.default' -exec rm -rf {} \;
#rm /root/.mozilla/firefox/*
#systemctl restart localbrowser.service


if [ -f "/srv/http/config/lmson" ]; then
    rm "/srv/http/config/lmson"
fi

if [ ! -f "/srv/http/config/yton" ]; then
    touch "/srv/http/config/yton"
fi

tar -xzvf /srv/http/config/unit/ytube.tar.gz --overwrite -C /
sleep 0.5
systemctl daemon-reload
systemctl restart localbrowser.service
systemctl enable localbrowser.service
sleep 2
tar -xzvf /srv/http/config/unit/exten.tgz --overwrite -C /root/.mozilla/firefox/*.default-release

sleep 1

chown -Rv http:http /root/.mozilla/firefox/*.default-release
sleep 1
