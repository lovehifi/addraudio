<?php
$commandre = "/usr/bin/sudo /bin/sleep 1 && /usr/bin/sudo /bin/reboot";
$outputre = shell_exec($commandre);

if ($outputre === null) {
    http_response_code(500);
    echo "Cannot reboot";
} else {
    http_response_code(200);
    echo "Reboot now";

}

?>

