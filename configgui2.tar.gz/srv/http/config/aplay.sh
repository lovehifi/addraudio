#!/bin/bash
aplay -l | grep ^card
