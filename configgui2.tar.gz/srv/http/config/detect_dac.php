<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['selected_device']) && is_numeric($_POST['selected_device'])) {
        $selected_card = intval($_POST['selected_device']);

        $new_content = "defaults.pcm.card {$selected_card}\n";
        $new_content .= "defaults.ctl.card {$selected_card}\n";

        $asound_conf_path = '/etc/asound.conf';
        file_put_contents($asound_conf_path, $new_content);

        echo "Choose Card: {$selected_card} for /etc/asound.conf. Please reboot!";
        exit();
    } else {
        echo "Invalid selected DAC card number. Please reboot!";
        exit();
    }
}

$command = "aplay -l";
$devices = shell_exec($command);

if ($devices === null) {
    $error_message = 'Cannot detect device with: ' . $command . '. Please reboot!';
    error_log($error_message);
    die($error_message);
}

preg_match_all('/card ([0-9]+): (.+?) \[.*?\]/', $devices, $matches, PREG_SET_ORDER);

$file_path = '/srv/http/config/dac.txt';
$contents = '';
foreach ($matches as $match) {
    $contents .= 'Card ' . $match[1] . ': ' . $match[2] . "\n";
}

file_put_contents($file_path, $contents);

echo '<div id="message" style="display: none;" class="alert-success alert"></div>';
echo '<select class="form-control" id="selected_device" name="selected_device">';
echo '<option disabled selected>DACs list:</option>';
foreach ($matches as $match) {
    echo '<option value="' . $match[1] . '">' . 'Card ' . $match[1] . ': ' . $match[2] . '</option>';
}
echo '</select>';

//$debug_log = "Script executed at " . date('Y-m-d H:i:s') . "\n";
//$debug_log .= "Output devices:\n" . $devices . "\n\n";
//$debug_log .= "Matches:\n" . print_r($matches, true) . "\n\n";
//$debug_log_file = '/srv/http/config/debug_log.txt';
//file_put_contents($debug_log_file, $debug_log, FILE_APPEND);
?>

<script>
function handleFormSubmit(event) {
    event.preventDefault();
    var selectedCard = document.getElementById("selected_device").value;
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "detect_dac.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            document.getElementById("message").innerText = xhr.responseText;
            document.getElementById("message").style.display = "block";
        }
    };
    xhr.send("selected_device=" + selectedCard);
}
</script>
