#!/bin/bash

CONFIG_INI="config.ini"
CONFIG_TXT="/boot/config.txt"

DTOVERLAY=$(awk -F "=" '/dtoverlay/ {print $2}' "$CONFIG_INI" | tr -d '[:space:]')
 echo "$DTOVERLAY"

function add_dtoverlay {
    echo "dtoverlay=$1" >> "$CONFIG_TXT"
}

function remove_dtoverlay {
    sed -i "/dtoverlay=/s/[^ ]*//" "$CONFIG_TXT"
}

if [ "$1" == "I2S" ]; then
    add_dtoverlay "$DTOVERLAY"
    echo 'DAC setting updated to I2S.'
elif [ "$1" == "USB" ]; then
    remove_dtoverlay
    echo 'DAC setting updated to USB.'
else
    echo 'Invalid DAC setting.'
fi
