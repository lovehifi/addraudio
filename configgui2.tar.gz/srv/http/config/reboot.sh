#!/bin/bash

sleep 2
reboot
