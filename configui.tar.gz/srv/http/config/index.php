<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DAC Setting Selector</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #1e1e1e;
            color: #ffffff;
        }
        .container {
            background-color: #2e2e2e;
            padding: 20px;
            border-radius: 10px;
            max-width: 600px;
            margin: 0 auto;
            margin-top: 50px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        #result {
            margin-top: 20px;
        }
        #resultMessage {
            font-size: 18px;
        }
        .out{
            color: #59c8ff;
            font-weight: 300;
        }

    </style>
</head>
<body>
<div class="container">
    <h3 class="text-center">Squeezelite output to <span id="dacSettingDisplay" class="out"></span></h3>

    <form id="dacForm">
        <div class="form-group">
            <label for="dacSetting">Select a DAC Setting:</label>
            <select class="form-control" id="dacSetting" name="dacSetting">
                <option value="default">Default - operates based on rAudio settings</option>
                <option value="eqfa12p">Eqfa12p - operates with 12-band Parametric EQ</option>
                <option value="auto">Auto - Automatically detects DAC hw:#</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Apply DAC Setting</button>
    </form>

    <div id="result" style="display: none;">
        <hr>
        <p id="resultMessage"></p>
    </div>
</div>

<div class="container">
    <h3 class="text-center">LMSBubV9</h3>
	    <div id="bubV9Result" style="display: none;" class="alert-success alert">
        <p id="bubV9ResultMessage"></p>
		 <hr>
    </div>
    <form id="bubV9Form">
        <div class="form-group">
            <label for="srvUsername">Username:</label>
            <input type="text" class="form-control" id="srvUsername" name="srvUsername">
        </div>
        <div class="form-group">
            <label for="srvPassword">Password:</label>
            <input type="password" class="form-control" id="srvPassword" name="srvPassword">
        </div>
        <div class="form-group">
            <label for="bubbleServerUrl">Bubble Server URL (http://yourserver:58050)</label>
            <input type="text" class="form-control" id="bubbleServerUrl" name="bubbleServerUrl">
        </div>
        <button type="submit" class="btn btn-primary btn-block">Apply Config</button>
    </form>


</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function runScript() {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState == XMLHttpRequest.DONE) {
                if (xhr.status == 200) {

                } else {

                }
            }
        };
        xhr.open("GET", "run_eq_script.php", true);
        xhr.send();
    }

    // Function to read the DAC setting from the file
    function readDacSetting() {
        $.ajax({
            url: 'read_dac_setting.php',
            method: 'GET',
            dataType: 'text',
            success: function (data) {
                // Display the DAC setting
                $('#dacSettingDisplay').text(data);
            },
            error: function (xhr, status, error) {
                console.error('Error reading DAC setting:', error);
            }
        });
    }

    // Call the function to read and display the DAC setting
    readDacSetting();

    document.getElementById('dacForm').addEventListener('submit', function(event) {
        event.preventDefault();

        const selectedSetting = document.getElementById('dacSetting').value;

        let command;
        if (selectedSetting === 'default') {
            command = 'Replaced successfully! The output: -o default.';
        } else if (selectedSetting === 'eqfa12p') {
            command = 'Replaced successfully! The output: -o eqfa12p.';
        } else if (selectedSetting === 'auto') {
            // Replace $card with the appropriate value for the 'auto' setting
            command = 'Replaced successfully! The output: -o hw:$card.';
        }

  document.getElementById('result').innerHTML = `<div class="alert alert-success">${command}</div>`;
    });
	
	   $(document).ready(function() {
        $('#dacForm').submit(function(e) {
            e.preventDefault(); // Prevent the default form submission

            var formData = $(this).serialize();

            $.ajax({
                type: 'POST',
                url: 'update_dac_setting.php',
                data: formData,
                success: function(response) {
                    // Display the result
                    runScript()
                    $('#result').show();
                    $('#resultMessage').text(response);
                }
            });
        });
    });

    $(document).ready(function() {
        $('#bubV9Form').submit(function(e) {
            e.preventDefault(); // Prevent the default form submission

            var formData = $(this).serialize();

            $.ajax({
                type: 'POST',
                url: 'update_bubv9_config.php',
                data: formData,
                success: function(response) {
                    // Display the result for BubV9
                    $('#bubV9Result').show();
                    $('#bubV9ResultMessage').text(response);
                }
            });
        });
    });
	
</script>

</body>
</html>
