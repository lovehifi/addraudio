<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dacSetting = $_POST['dacSetting'];
    $filePath = '/opt/sq/sq.sh';

    $dacOptions = [
        'default' => '-o default',
        'eqfa12p' => '-o eqfa12p',
        'auto' => '-o hw:$card'
    ];

    if (isset($dacOptions[$dacSetting])) {
        $content = file_get_contents($filePath);
        $content = preg_replace('/-o\s+[^\s]+/', $dacOptions[$dacSetting], $content, 1);
        
        if ($content !== null) {
            file_put_contents($filePath, $content);
            $resultMessage = 'DAC Setting updated successfully.';
            $updatedCommand = '/opt/sq/squeezelite64 ' . $dacOptions[$dacSetting] . ' -n SQ64-rAudio -s 127.0.0.1 -m 00:00:00:00:00:00 -W';
        } else {
            $resultMessage = 'Failed to update DAC Setting.';
            $updatedCommand = '';
        }
    } else {
        $resultMessage = 'Invalid DAC Setting.';
        $updatedCommand = '';
    }

    // Return the result as JSON
    echo json_encode(['resultMessage' => $resultMessage, 'updatedCommand' => $updatedCommand]);
}
?>
